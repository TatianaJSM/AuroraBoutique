﻿using AppAuroraBoutique.Modelo;
using Npgsql;
using System.Collections.Generic;

namespace AppAuroraBoutique.DA
{
    public class ClienteDAO
    {
        private readonly string _connectionString;

        public ClienteDAO(string DefaultConnection)
        {
            _connectionString = DefaultConnection;
        }

        public bool RegistrarCliente(Cliente cliente, LoginCliente login, Direccion direccion, List<Correo> correos, List<Telefono> telefonos)
        {
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            using var trans = conn.BeginTransaction();
            try
            {
                // Insert Cliente
                var cmdCliente = new NpgsqlCommand(
                    "INSERT INTO auroraboutique.Cliente (Nombre, PrimerApellido, SegundoApellido) VALUES (@Nombre, @PA, @SA) RETURNING IdCliente",
                    conn, trans);
                cmdCliente.Parameters.AddWithValue("Nombre", cliente.Nombre);
                cmdCliente.Parameters.AddWithValue("PA", cliente.PrimerApellido);
                cmdCliente.Parameters.AddWithValue("SA", (object?)cliente.SegundoApellido ?? DBNull.Value);
                cliente.IdCliente = (int)cmdCliente.ExecuteScalar();

                // Insert Login
                var cmdLogin = new NpgsqlCommand(
                    "INSERT INTO auroraboutique.LoginCliente (IdCliente, Usuario, Contrasena) VALUES (@IdCliente, @Usuario, @Contrasena)",
                    conn, trans);
                cmdLogin.Parameters.AddWithValue("IdCliente", cliente.IdCliente);
                cmdLogin.Parameters.AddWithValue("Usuario", login.Usuario);
                cmdLogin.Parameters.AddWithValue("Contrasena", login.Contrasena);
                cmdLogin.ExecuteNonQuery();

                // Insert Dirección
                var cmdDireccion = new NpgsqlCommand(
                    "INSERT INTO auroraboutique.Direccion (IdCliente, IdBarrio, IdDistrito, IdCanton, IdProvincia, IdPais, Detalles) VALUES (@IdCliente, @Barrio, @Distrito, @Canton, @Provincia, @Pais, @Detalles)",
                    conn, trans);
                cmdDireccion.Parameters.AddWithValue("IdCliente", cliente.IdCliente);
                cmdDireccion.Parameters.AddWithValue("Barrio", direccion.IdBarrio);
                cmdDireccion.Parameters.AddWithValue("Distrito", direccion.IdDistrito);
                cmdDireccion.Parameters.AddWithValue("Canton", direccion.IdCanton);
                cmdDireccion.Parameters.AddWithValue("Provincia", direccion.IdProvincia);
                cmdDireccion.Parameters.AddWithValue("Pais", direccion.IdPais);
                cmdDireccion.Parameters.AddWithValue("Detalles", (object?)direccion.Detalles ?? DBNull.Value);
                cmdDireccion.ExecuteNonQuery();

                // Insert Correos
                foreach (var correo in correos)
                {
                    var cmdCorreo = new NpgsqlCommand(
                        "INSERT INTO auroraboutique.Correo (IdCliente, Email) VALUES (@IdCliente, @Email)",
                        conn, trans);
                    cmdCorreo.Parameters.AddWithValue("IdCliente", cliente.IdCliente);
                    cmdCorreo.Parameters.AddWithValue("Email", correo.Email);
                    cmdCorreo.ExecuteNonQuery();
                }

                // Insert Teléfonos
                foreach (var tel in telefonos)
                {
                    var cmdTel = new NpgsqlCommand(
                        "INSERT INTO auroraboutique.Telefono (IdCliente, Numero) VALUES (@IdCliente, @Numero)",
                        conn, trans);
                    cmdTel.Parameters.AddWithValue("IdCliente", cliente.IdCliente);
                    cmdTel.Parameters.AddWithValue("Numero", tel.Numero);
                    cmdTel.ExecuteNonQuery();
                }

                trans.Commit();
                return true;
            }
            catch
            {
                trans.Rollback();
                return false;
            }
        }

        public Cliente? LoginCliente(string usuario, string contrasena)
        {
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            var cmd = new NpgsqlCommand(@"
                SELECT c.IdCliente, c.Nombre, c.PrimerApellido, c.SegundoApellido
                FROM auroraboutique.LoginCliente lc
                JOIN auroraboutique.Cliente c ON lc.IdCliente = c.IdCliente
                WHERE lc.Usuario = @Usuario AND lc.Contrasena = @Contrasena", conn);

            cmd.Parameters.AddWithValue("Usuario", usuario);
            cmd.Parameters.AddWithValue("Contrasena", contrasena);

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return new Cliente
                {
                    IdCliente = reader.GetInt32(0),
                    Nombre = reader.GetString(1),
                    PrimerApellido = reader.GetString(2),
                    SegundoApellido = reader.IsDBNull(3) ? null : reader.GetString(3)
                };
            }

            return null;
        }

        public bool EditarCliente(Cliente cliente)
        {
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            var cmd = new NpgsqlCommand(@"
                UPDATE auroraboutique.Cliente
                SET Nombre = @Nombre, PrimerApellido = @PA, SegundoApellido = @SA
                WHERE IdCliente = @Id", conn);
            cmd.Parameters.AddWithValue("Nombre", cliente.Nombre);
            cmd.Parameters.AddWithValue("PA", cliente.PrimerApellido);
            cmd.Parameters.AddWithValue("SA", (object?)cliente.SegundoApellido ?? DBNull.Value);
            cmd.Parameters.AddWithValue("Id", cliente.IdCliente);

            return cmd.ExecuteNonQuery() > 0;
        }

        public bool EliminarCliente(int idCliente)
        {
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            var cmd = new NpgsqlCommand("DELETE FROM auroraboutique.Cliente WHERE IdCliente = @Id", conn);
            cmd.Parameters.AddWithValue("Id", idCliente);
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool AgregarCorreo(int idCliente, string email)
        {
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            var cmd = new NpgsqlCommand(
                "INSERT INTO auroraboutique.Correo (IdCliente, Email) VALUES (@IdCliente, @Email)", conn);
            cmd.Parameters.AddWithValue("IdCliente", idCliente);
            cmd.Parameters.AddWithValue("Email", email);
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool AgregarTelefono(int idCliente, string numero)
        {
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            var cmd = new NpgsqlCommand(
                "INSERT INTO auroraboutique.Telefono (IdCliente, Numero) VALUES (@IdCliente, @Numero)", conn);
            cmd.Parameters.AddWithValue("IdCliente", idCliente);
            cmd.Parameters.AddWithValue("Numero", numero);
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool AgregarDireccion(Direccion direccion)
        {
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            var cmd = new NpgsqlCommand(@"
                INSERT INTO auroraboutique.Direccion
                (IdCliente, IdBarrio, IdDistrito, IdCanton, IdProvincia, IdPais, Detalles)
                VALUES (@IdCliente, @Barrio, @Distrito, @Canton, @Provincia, @Pais, @Detalles)", conn);

            cmd.Parameters.AddWithValue("IdCliente", direccion.IdCliente);
            cmd.Parameters.AddWithValue("Barrio", direccion.IdBarrio);
            cmd.Parameters.AddWithValue("Distrito", direccion.IdDistrito);
            cmd.Parameters.AddWithValue("Canton", direccion.IdCanton);
            cmd.Parameters.AddWithValue("Provincia", direccion.IdProvincia);
            cmd.Parameters.AddWithValue("Pais", direccion.IdPais);
            cmd.Parameters.AddWithValue("Detalles", (object?)direccion.Detalles ?? DBNull.Value);

            return cmd.ExecuteNonQuery() > 0;
        }

        public Cliente? ObtenerClientePorId(int idCliente)
        {
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            Cliente? cliente = null;

            // Datos básicos
            var cmd = new NpgsqlCommand(@"
                SELECT IdCliente, Nombre, PrimerApellido, SegundoApellido
                FROM auroraboutique.Cliente
                WHERE IdCliente = @IdCliente", conn);
            cmd.Parameters.AddWithValue("IdCliente", idCliente);

            using (var reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    cliente = new Cliente
                    {
                        IdCliente = reader.GetInt32(0),
                        Nombre = reader.GetString(1),
                        PrimerApellido = reader.GetString(2),
                        SegundoApellido = reader.IsDBNull(3) ? null : reader.GetString(3),
                        Correos = new List<Correo>(),
                        Telefonos = new List<Telefono>()
                    };
                }
            }

            if (cliente == null)
                return null;

            // Correos
            var cmdCorreo = new NpgsqlCommand(
                "SELECT IdCorreo, Email FROM auroraboutique.Correo WHERE IdCliente = @IdCliente", conn);
            cmdCorreo.Parameters.AddWithValue("IdCliente", idCliente);
            using (var reader = cmdCorreo.ExecuteReader())
            {
                while (reader.Read())
                {
                    cliente.Correos.Add(new Correo
                    {
                        IdCorreo = reader.GetInt32(0),
                        IdCliente = idCliente,
                        Email = reader.GetString(1)
                    });
                }
            }

            // Teléfonos
            var cmdTel = new NpgsqlCommand(
                "SELECT IdTelefono, Numero FROM auroraboutique.Telefono WHERE IdCliente = @IdCliente", conn);
            cmdTel.Parameters.AddWithValue("IdCliente", idCliente);
            using (var reader = cmdTel.ExecuteReader())
            {
                while (reader.Read())
                {
                    cliente.Telefonos.Add(new Telefono
                    {
                        IdTelefono = reader.GetInt32(0),
                        IdCliente = idCliente,
                        Numero = reader.GetString(1)
                    });
                }
            }

            // Dirección
            var cmdDir = new NpgsqlCommand(
                "SELECT IdDireccion, IdBarrio, IdDistrito, IdCanton, IdProvincia, IdPais  FROM auroraboutique.Direccion WHERE IdCliente = @IdCliente", conn);
            cmdDir.Parameters.AddWithValue("IdCliente", idCliente);
            using (var reader = cmdDir.ExecuteReader())
            {
                if (reader.Read())
                {
                    cliente.Direccion = new Direccion
                    {
                        IdDireccion = reader.GetInt32(0),
                        IdCliente = idCliente,
                        IdBarrio = reader.GetInt32(1),
                        IdDistrito = reader.GetInt32(2),
                        IdCanton = reader.GetInt32(3),
                        IdProvincia = reader.GetInt32(4),
                        IdPais = reader.GetInt32(5),
                        
                    };
                }
            }

            return cliente;
        }
    }
}

