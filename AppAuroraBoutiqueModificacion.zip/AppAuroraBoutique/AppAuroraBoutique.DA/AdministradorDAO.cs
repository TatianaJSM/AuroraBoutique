﻿using AppAuroraBoutique.Modelo;
using Npgsql;

namespace AppAuroraBoutique.DA
{
    public class AdministradorDAO
    {
        private readonly string _connectionString;

        public AdministradorDAO(string defaultConnection)
        {
            _connectionString = defaultConnection;
        }

        public Administrador? LoginAdministrador(string usuario, string contrasena)
        {
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            var cmd = new NpgsqlCommand(@"
                SELECT a.IdAdministrador, a.Nombre, a.PrimerApellido, a.SegundoApellido
                FROM auroraboutique.LoginAdministrador la
                JOIN auroraboutique.Administrador a ON la.IdAdministrador = a.IdAdministrador
                WHERE la.Usuario = @Usuario AND la.Contrasena = @Contrasena", conn);

            cmd.Parameters.AddWithValue("Usuario", usuario);
            cmd.Parameters.AddWithValue("Contrasena", contrasena);

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return new Administrador
                {
                    IdAdministrador = reader.GetInt32(0),
                    Nombre = reader.GetString(1),
                    PrimerApellido = reader.GetString(2),
                    SegundoApellido = reader.IsDBNull(3) ? null : reader.GetString(3),
                    Usuario = usuario,
                    Contrasena = contrasena
                };
            }

            return null;
        }

        public DashboardAdminViewModel ObtenerDashboardAdmin()
        {
            var dashboard = new DashboardAdminViewModel();

            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            // Pedidos sin personal de envío asignado
            using (var cmd = new NpgsqlCommand(@"
        SELECT p.IdPedido, c.Nombre || ' ' || c.PrimerApellido AS Cliente, e.Nombre AS Estado
        FROM auroraboutique.Pedido p
        JOIN auroraboutique.Cliente c ON p.IdCliente = c.IdCliente
        JOIN auroraboutique.Estados e ON p.IdEstado = e.IdEstado
        LEFT JOIN auroraboutique.PedidoPersonalEnvio pe ON p.IdPedido = pe.IdPedido
        WHERE pe.IdPedido IS NULL
        ORDER BY p.IdPedido DESC", conn))
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    dashboard.PedidosSinPersonal.Add(new PedidoDashboardViewModel
                    {
                        IdPedido = reader.GetInt32(0),
                        Cliente = reader.GetString(1),
                        Estado = reader.GetString(2),
                        PersonalEnvio = null
                    });
                }
            }

            // Pedidos ya asignados a personal de envío
            using (var cmd = new NpgsqlCommand(@"
        SELECT p.IdPedido, c.Nombre || ' ' || c.PrimerApellido AS Cliente, e.Nombre AS Estado, per.Nombre || ' ' || per.PrimerApellido AS PersonalEnvio
        FROM auroraboutique.Pedido p
        JOIN auroraboutique.Cliente c ON p.IdCliente = c.IdCliente
        JOIN auroraboutique.Estados e ON p.IdEstado = e.IdEstado
        JOIN auroraboutique.PedidoPersonalEnvio pe ON p.IdPedido = pe.IdPedido
        JOIN auroraboutique.PersonalEnvio per ON pe.IdPersonalEnvio = per.IdPersonalEnvio
        ORDER BY p.IdPedido DESC", conn))
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    dashboard.PedidosAsignados.Add(new PedidoDashboardViewModel
                    {
                        IdPedido = reader.GetInt32(0),
                        Cliente = reader.GetString(1),
                        Estado = reader.GetString(2),
                        PersonalEnvio = reader.GetString(3)
                    });
                }
            }

            // Reseñas
            using (var cmd = new NpgsqlCommand(@"
        SELECT r.IdResena, c.Nombre || ' ' || c.PrimerApellido AS Cliente, p.Nombre AS Producto, r.Calificacion, r.Comentario
        FROM auroraboutique.Resena r
        JOIN auroraboutique.Cliente c ON r.IdCliente = c.IdCliente
        JOIN auroraboutique.Productos p ON r.IdProducto = p.IdProducto
        ORDER BY r.IdResena DESC", conn))
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    dashboard.Resenas.Add(new ResenaDashboardViewModel
                    {
                        IdResena = reader.GetInt32(0),
                        Cliente = reader.GetString(1),
                        Producto = reader.GetString(2),
                        Calificacion = reader.GetInt32(3),
                        Comentario = reader.IsDBNull(4) ? "" : reader.GetString(4)
                    });
                }
            }

            return dashboard;
        }
    }
    }






