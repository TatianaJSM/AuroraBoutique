﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AppAuroraBoutique.Modelo;
using Npgsql;

namespace AppAuroraBoutique.DA
{
    public class ProductoDAO
    {
        private readonly string _connectionString;

        public ProductoDAO(string connectionString)
        {
            _connectionString = connectionString;
        }

        public List<Producto> ObtenerCatalogo()
        {
            var productos = new List<Producto>();
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            string sql = @"
            SELECT p.IdProducto, p.Nombre, p.Descripcion, p.Precio, p.CantidadStock, c.Nombre AS CategoriaNombre
            FROM auroraboutique.Productos p
            JOIN auroraboutique.Categoria c ON p.IdCategoria = c.IdCategoria
        ";

            using var cmd = new NpgsqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                productos.Add(new Producto
                {
                    IdProducto = reader.GetInt32(0),
                    Nombre = reader.GetString(1),
                    Descripcion = reader.GetString(2),
                    Precio = reader.GetDecimal(3),
                    CantidadStock = reader.GetInt32(4),
                    CategoriaNombre = reader.GetString(5)
                });
            }

            return productos;
        }
    }

}
