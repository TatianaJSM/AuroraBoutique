﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AppAuroraBoutique.DA;
using AppAuroraBoutique.Modelo;

namespace AppAuroraBoutique.BL
{
    public class GestorAdministrador
    {
        private readonly AdministradorDAO _adminDAO;

        public GestorAdministrador(string defaultConnection)
        {
            _adminDAO = new AdministradorDAO(defaultConnection);
        }

        public Administrador? AutenticarAdministrador(string usuario, string contrasena)
        {
            return _adminDAO.LoginAdministrador(usuario, contrasena);
        }
    }

}
