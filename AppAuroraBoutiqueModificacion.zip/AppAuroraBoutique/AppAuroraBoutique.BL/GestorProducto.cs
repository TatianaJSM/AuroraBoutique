﻿using System;
using System.Collections.Generic;
using AppAuroraBoutique.DA;
using AppAuroraBoutique.Modelo;
using System.Collections.Generic;

public class GestorProducto
{
    private readonly ProductoDAO _productoDAO;

    public GestorProducto(string connectionString)
    {
        _productoDAO = new ProductoDAO(connectionString);
    }

    public List<Producto> ObtenerCatalogo()
    {
        return _productoDAO.ObtenerCatalogo();
    }

    // Opcional: búsqueda
    public List<Producto> BuscarProductos(string busqueda)
    {
        // Implementa este método si quieres búsqueda, si no, omítelo
        return _productoDAO.ObtenerCatalogo()
            .FindAll(p => p.Nombre.Contains(busqueda, StringComparison.OrdinalIgnoreCase) ||
                          p.Descripcion.Contains(busqueda, StringComparison.OrdinalIgnoreCase) ||
                          p.CategoriaNombre.Contains(busqueda, StringComparison.OrdinalIgnoreCase));
    }
}

