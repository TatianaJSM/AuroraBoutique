﻿using AppAuroraBoutique.Modelo;
using AppAuroraBoutique.DA;
using System.Collections.Generic;

namespace AppAuroraBoutique.BL
{
    public class GestorCliente
    {
        private readonly ClienteDAO _clienteDAO;

        public GestorCliente(string defaultConnection)
        {
            _clienteDAO = new ClienteDAO(defaultConnection);
        }

        public bool RegistrarClienteCompleto(Cliente cliente, LoginCliente login, Direccion direccion, List<Correo> correos, List<Telefono> telefonos)
        {
            return _clienteDAO.RegistrarCliente(cliente, login, direccion, correos, telefonos);
        }

        public Cliente? AutenticarCliente(string usuario, string contrasena)
        {
            return _clienteDAO.LoginCliente(usuario, contrasena);
        }

        public bool EditarInformacionPersonal(Cliente cliente)
        {
            return _clienteDAO.EditarCliente(cliente);
        }

        public bool EliminarCuenta(int idCliente)
        {
            return _clienteDAO.EliminarCliente(idCliente);
        }

        public bool AgregarCorreo(int idCliente, string email)
        {
            return _clienteDAO.AgregarCorreo(idCliente, email);
        }

        public bool AgregarTelefono(int idCliente, string numero)
        {
            return _clienteDAO.AgregarTelefono(idCliente, numero);
        }

        public bool AgregarDireccion(Direccion direccion)
        {
            return _clienteDAO.AgregarDireccion(direccion);
        }

        public Cliente? ObtenerClientePorId(int idCliente)
        {
            return _clienteDAO.ObtenerClientePorId(idCliente);
        }
    }
}


