﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAuroraBoutique.Modelo
{
    public class Direccion
    {
        public int IdDireccion { get; set; }
        public int IdCliente { get; set; }

        public int IdBarrio { get; set; }
        public int IdDistrito { get; set; }
        public int IdCanton { get; set; }
        public int IdProvincia { get; set; }
        public int IdPais { get; set; }

        public string? Detalles { get; set; } // opcional
    }

}
