﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAuroraBoutique.Modelo
{
    public class LoginCliente
    {
        public int IdLoginCliente { get; set; }
        public int IdCliente { get; set; }
        public string Usuario { get; set; }
        public string Contrasena { get; set; }

        public Cliente Cliente { get; set; }
    }

}
