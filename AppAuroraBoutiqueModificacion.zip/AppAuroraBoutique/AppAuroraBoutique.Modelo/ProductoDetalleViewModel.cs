﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAuroraBoutique.Modelo
{
    public class ProductoDetalleViewModel
    {
        public Producto Producto { get; set; }
        public List<Talla> TallasDisponibles { get; set; }
        public List<Color> ColoresDisponibles { get; set; }
    }

}
