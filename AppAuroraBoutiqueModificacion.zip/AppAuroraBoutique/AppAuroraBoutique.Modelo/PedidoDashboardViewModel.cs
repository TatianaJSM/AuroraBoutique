﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAuroraBoutique.Modelo
{
    public class PedidoDashboardViewModel
    {
        public int IdPedido { get; set; }
        public string Cliente { get; set; }
        public string Estado { get; set; }
        public string? PersonalEnvio { get; set; }
    }
}
