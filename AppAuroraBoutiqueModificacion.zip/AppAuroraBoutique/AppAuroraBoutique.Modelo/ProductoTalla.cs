﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAuroraBoutique.Modelo
{
    public class ProductoTalla
    {
        public int IdProducto { get; set; }
        public int IdTalla { get; set; }

        public Producto Producto { get; set; }
        public Talla Talla { get; set; }
    }

}
