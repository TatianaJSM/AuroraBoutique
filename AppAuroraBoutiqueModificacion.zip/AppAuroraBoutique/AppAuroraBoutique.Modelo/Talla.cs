﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAuroraBoutique.Modelo
{
    public class Talla
    {
        public int IdTalla { get; set; }
        public string Descripcion { get; set; }
    }

}
