﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAuroraBoutique.Modelo
{
    public class ResenaDashboardViewModel
    {
        public int IdResena { get; set; }
        public string Cliente { get; set; }
        public string Producto { get; set; }
        public int Calificacion { get; set; }
        public string Comentario { get; set; }
    }
}
