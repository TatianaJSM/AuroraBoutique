﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAuroraBoutique.Modelo
{
    public class Correo
    {
        public int IdCorreo { get; set; }
        public int IdCliente { get; set; }
        public string Email { get; set; }
    }

}
