﻿namespace AppAuroraBoutique.Modelo
{
    public class Cliente
    {
        public int IdCliente { get; set; }
        public string Nombre { get; set; }
        public string PrimerApellido { get; set; }
        public string? SegundoApellido { get; set; }

        public List<Correo> Correos { get; set; }
        public List<Telefono> Telefonos { get; set; }
        public Direccion Direccion { get; set; }
    }

}
