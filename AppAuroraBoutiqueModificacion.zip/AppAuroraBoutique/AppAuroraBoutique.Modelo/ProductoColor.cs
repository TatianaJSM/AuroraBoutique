﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAuroraBoutique.Modelo
{
    public class ProductoColor
    {
        public int IdProducto { get; set; }
        public int IdColor { get; set; }

        public Producto Producto { get; set; }
        public Color Color { get; set; }
    }

}
