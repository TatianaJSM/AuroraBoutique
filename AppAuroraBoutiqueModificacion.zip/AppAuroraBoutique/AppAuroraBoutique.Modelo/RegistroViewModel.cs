﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAuroraBoutique.Modelo
{
    public class RegistroViewModel
    {
        public Cliente Cliente { get; set; }
        public LoginCliente Login { get; set; }
        public Direccion Direccion { get; set; }
        public string CorreosConcatenados { get; set; } // separados por coma
        public string TelefonosConcatenados { get; set; }
    }

}
