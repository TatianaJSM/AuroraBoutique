﻿using System.Collections.Generic;

namespace AppAuroraBoutique.Modelo
{
    public class DashboardAdminViewModel

    {
        public List<PedidoDashboardViewModel> PedidosSinPersonal { get; set; } = new();
        public List<PedidoDashboardViewModel> PedidosAsignados { get; set; } = new();
        public List<ResenaDashboardViewModel> Resenas { get; set; } = new();
    }
}

