﻿using Microsoft.AspNetCore.Mvc;
using AppAuroraBoutique.BL;
using AppAuroraBoutique.Modelo;

namespace AppAuroraBoutique.UI.Controllers
{
    public class AdministradorController : Controller
    {
        private readonly GestorAdministrador _gestor;
        private readonly string _connectionString;

        public AdministradorController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection") ?? "";
            _gestor = new GestorAdministrador(_connectionString);
        }

        // GET: /Administrador/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // POST: /Administrador/Login
        [HttpPost]
        public IActionResult Login(string usuario, string contrasena)
        {
            var admin = _gestor.AutenticarAdministrador(usuario, contrasena);
            if (admin != null)
            {
                // Aquí puedes guardar la sesión si lo necesitas
                return RedirectToAction("Dashboard");
            }
            ViewBag.Error = "Usuario o contraseña incorrectos";
            return View();
        }

        // GET: /Administrador/Dashboard
        [HttpGet]
        public IActionResult Dashboard()
        {
            var dao = new AppAuroraBoutique.DA.AdministradorDAO(_connectionString);
            var dashboard = dao.ObtenerDashboardAdmin();
            return View(dashboard);
        }


        // Puedes agregar aquí más acciones para CRUD de administradores si lo necesitas
    }
}


