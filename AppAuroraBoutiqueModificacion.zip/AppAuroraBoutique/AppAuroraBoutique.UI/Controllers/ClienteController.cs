using Microsoft.AspNetCore.Mvc;
using AppAuroraBoutique.BL;
using AppAuroraBoutique.Modelo;
using System.Collections.Generic;
using System.Linq;

public class ClienteController : Controller
{
    private readonly GestorCliente _gestor;

    public ClienteController(GestorCliente gestor)
    {
        _gestor = gestor;
    }

    // GET: /Cliente/Registro
    public IActionResult Registro()
    {
        // Inicializa el modelo para evitar referencias nulas en la vista
        var model = new RegistroViewModel
        {
            Cliente = new Cliente(),
            Login = new LoginCliente(),
            Direccion = new Direccion(),
            CorreosConcatenados = "",
            TelefonosConcatenados = ""
        };
        return View(model);
    }

    // POST: /Cliente/Registro
    [HttpPost]
    public IActionResult Registro(RegistroViewModel model)
    {
        // Asegura que los objetos no sean nulos
        model.Cliente ??= new Cliente();
        model.Login ??= new LoginCliente();
        model.Direccion ??= new Direccion();

        if (ModelState.IsValid)
        {
            // Procesar correos
            var correos = new List<Correo>();
            if (!string.IsNullOrWhiteSpace(model.CorreosConcatenados))
            {
                correos = model.CorreosConcatenados
                    .Split(',', System.StringSplitOptions.RemoveEmptyEntries)
                    .Select(email => new Correo { Email = email.Trim() })
                    .ToList();
            }

            // Procesar tel�fonos
            var telefonos = new List<Telefono>();
            if (!string.IsNullOrWhiteSpace(model.TelefonosConcatenados))
            {
                telefonos = model.TelefonosConcatenados
                    .Split(',', System.StringSplitOptions.RemoveEmptyEntries)
                    .Select(num => new Telefono { Numero = num.Trim() })
                    .ToList();
            }

            try
            {
                var resultado = _gestor.RegistrarClienteCompleto(
                    model.Cliente,
                    model.Login,
                    model.Direccion,
                    correos,
                    telefonos
                );

                if (resultado)
                    return RedirectToAction("Login");

                ModelState.AddModelError("", "Error al registrar el cliente. Verifica los datos ingresados.");
            }
            catch (Exception ex)
            {
                // Muestra el error real en la vista para depuraci�n
                ModelState.AddModelError("", $"Error inesperado: {ex.Message}");
            }
        }
        return View(model);
    }

    // GET: /Cliente/Login
    public IActionResult Login()
    {
        return View();
    }

    // POST: /Cliente/Login
    [HttpPost]
    [HttpPost]
    public IActionResult Login(string usuario, string contrasena)
    {
        var cliente = _gestor.AutenticarCliente(usuario, contrasena);
        if (cliente != null)
        {
            HttpContext.Session.SetInt32("IdCliente", cliente.IdCliente);
            HttpContext.Session.SetString("NombreCliente", cliente.Nombre);
            // Redirige al cat�logo de productos (p�gina principal)
            return RedirectToAction("Catalogo", "Producto");
        }

        ModelState.AddModelError("", "Credenciales incorrectas.");
        return View();
    }



    // GET: /Cliente/Perfil
    public IActionResult Perfil()
    {
        var idCliente = HttpContext.Session.GetInt32("IdCliente");
        if (idCliente == null)
            return RedirectToAction("Login");

        var cliente = _gestor.ObtenerClientePorId(idCliente.Value);
        if (cliente == null)
            return RedirectToAction("Login");

        return View(cliente);
    }


    // POST: /Cliente/Editar
    [HttpPost]
    public IActionResult Editar(Cliente cliente)
    {
        if (ModelState.IsValid)
        {
            var result = _gestor.EditarInformacionPersonal(cliente);
            if (result)
                return RedirectToAction("Perfil");
            ModelState.AddModelError("", "Error al actualizar los datos.");
        }
        return View("Perfil", cliente);
    }

    // POST: /Cliente/Eliminar
    [HttpPost]
    public IActionResult Eliminar(int id)
    {
        var eliminado = _gestor.EliminarCuenta(id);
        if (eliminado)
            return RedirectToAction("Login");

        ModelState.AddModelError("", "No se pudo eliminar la cuenta.");
        return RedirectToAction("Perfil");
    }

    // GET: /Cliente/AgregarCorreo
    public IActionResult AgregarCorreo()
    {
        if (!TempData.ContainsKey("IdCliente")) return RedirectToAction("Login");
        ViewBag.IdCliente = TempData["IdCliente"];
        return View();
    }

    // POST: /Cliente/AgregarCorreo
    [HttpPost]
    public IActionResult AgregarCorreo(string email)
    {
        int idCliente = Convert.ToInt32(TempData["IdCliente"]);
        var ok = _gestor.AgregarCorreo(idCliente, email);
        if (ok)
            return RedirectToAction("Perfil");

        ModelState.AddModelError("", "Error al agregar correo.");
        return View();
    }

    // GET: /Cliente/AgregarTelefono
    public IActionResult AgregarTelefono()
    {
        if (!TempData.ContainsKey("IdCliente")) return RedirectToAction("Login");
        ViewBag.IdCliente = TempData["IdCliente"];
        return View();
    }

    // POST: /Cliente/AgregarTelefono
    [HttpPost]
    public IActionResult AgregarTelefono(string numero)
    {
        int idCliente = Convert.ToInt32(TempData["IdCliente"]);
        var ok = _gestor.AgregarTelefono(idCliente, numero);
        if (ok)
            return RedirectToAction("Perfil");

        ModelState.AddModelError("", "Error al agregar tel�fono.");
        return View();
    }

    // GET: /Cliente/AgregarDireccion
    public IActionResult AgregarDireccion()
    {
        return View();
    }

    // POST: /Cliente/AgregarDireccion
    [HttpPost]
    public IActionResult AgregarDireccion(Direccion direccion)
    {
        direccion.IdCliente = Convert.ToInt32(TempData["IdCliente"]);
        var ok = _gestor.AgregarDireccion(direccion);
        if (ok)
            return RedirectToAction("Perfil");

        ModelState.AddModelError("", "Error al agregar direcci�n.");
        return View(direccion);
    }
    [HttpPost]
    public IActionResult CerrarSesion()
    {
        // Limpia toda la sesi�n del usuario
        HttpContext.Session.Clear();
        // Redirige al cat�logo de productos (p�gina principal)
        return RedirectToAction("Catalogo", "Producto");
    }

}


