﻿using Microsoft.AspNetCore.Mvc;
using AppAuroraBoutique.BL;

public class ProductoController : Controller
{
    private readonly GestorProducto _gestor;

    public ProductoController(GestorProducto gestor)
    {
        _gestor = gestor;
    }

    // Vista principal del catálogo
    public IActionResult Catalogo(string busqueda = null)
    {
        var productos = string.IsNullOrWhiteSpace(busqueda)
            ? _gestor.ObtenerCatalogo()
            : _gestor.BuscarProductos(busqueda);

        return View(productos);
    }
}

