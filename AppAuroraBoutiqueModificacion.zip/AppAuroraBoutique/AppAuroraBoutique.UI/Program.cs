using AppAuroraBoutique.BL;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});



// Obtener la cadena de conexi�n desde la configuraci�n
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");


// Registrar GestorProducto como servicio
builder.Services.AddScoped<GestorProducto>(_ => new GestorProducto(connectionString));


// Registrar GestorCliente como servicio
builder.Services.AddScoped<GestorCliente>(_ => new GestorCliente(connectionString));

builder.Services.AddScoped<GestorAdministrador>(_ => new GestorAdministrador(connectionString));


var app = builder.Build();


// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();
app.UseSession();
app.UseAuthorization();

app.MapStaticAssets();


app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Producto}/{action=Catalogo}/{id?}")
    .WithStaticAssets();


app.Run();
